import { NextResponse } from "next/server"

// This is a simple API route that returns simulated rover state data
// It allows the frontend to work without the Python backend
export async function GET() {
  // Generate some random data for simulation
  const batteryLevel = Math.random() * 100
  const isCharging = batteryLevel < 10
  const commsOk = batteryLevel >= 10

  // Create a response object that matches the expected backend format
  const response = {
    initialized: true,
    session_id: "NX-5432",
    connection_status: commsOk ? "Connected" : "Comms Lost",
    last_updated: Date.now() / 1000,
    rover_status: isCharging ? "Charging" : commsOk ? "Exploring" : "Comms Lost",
    position: {
      x: 45 + Math.random() * 2,
      y: 78 + Math.random() * 2,
    },
    battery_level: batteryLevel,
    is_charging: isCharging,
    comms_ok: commsOk,
    sensors: {
      ultrasonic_distance: 150 + (Math.random() * 20 - 10),
      ir_signal_strength: Math.random() * 100,
      rfid_detected: Math.random() > 0.7,
      accelerometer: {
        x: Math.random() * 0.1 - 0.05,
        y: Math.random() * 0.1 - 0.05,
        z: 0.98 + (Math.random() * 0.04 - 0.02),
      },
    },
    survivors_found:
      Math.random() > 0.7
        ? [
            {
              id: 1,
              position: {
                x: 45 + Math.random() * 2,
                y: 78 + Math.random() * 2,
              },
              timestamp: new Date().toISOString(),
              sensor_type: Math.random() > 0.5 ? "RFID" : "IR",
              signal_strength: Math.random() > 0.5 ? Math.round(Math.random() * 100) : "N/A",
            },
          ]
        : [],
    path_history: Array.from({ length: 10 }, (_, i) => ({
      x: 45 + i * 0.2 + Math.random() * 0.1,
      y: 78 + i * 0.2 + Math.random() * 0.1,
    })),
    last_error: null,
    last_action_sent: null,
  }

  return NextResponse.json(response)
}

