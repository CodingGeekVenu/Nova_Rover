"use client"

import { useState, useEffect, useRef } from "react"
import {
  Moon,
  Sun,
  Activity,
  Battery,
  Zap,
  Wifi,
  MapPin,
  Ruler,
  Radio,
  Play,
  Square,
  AlertTriangle,
  Check,
  X,
  User,
  Truck,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ScrollArea } from "@/components/ui/scroll-area"

// Types for our rover state
interface RoverState {
  roverId: string
  status: string
  batteryLevel: number
  isCharging: boolean
  communicationStatus: "OK" | "Lost" | "Intermittent"
  position: { x: number; y: number }
  ultrasonicDistance: number
  survivorSensors: {
    rfidDetected: boolean
    irSignal: number
  }
  accelerometer: {
    x: number
    y: number
    z: number
    isTilted: boolean
  }
}

interface SurvivorLog {
  id: number
  x: number
  y: number
  timestamp: string
  sensorType: "RFID" | "IR"
  signalStrength?: number
}

interface LogEntry {
  id: number
  message: string
  timestamp: string
  type: "info" | "warning" | "error" | "success"
}

// Backend API response interface
interface BackendState {
  initialized: boolean
  session_id: string
  connection_status: string
  last_updated: number
  rover_status: string
  position: { x: number; y: number }
  battery_level: number
  is_charging: boolean
  comms_ok: boolean
  sensors: {
    ultrasonic_distance?: number
    ir_signal_strength?: number
    rfid_detected?: boolean
    accelerometer?: {
      x: number
      y: number
      z: number
    }
  }
  survivors_found: Array<{
    id: number
    position: { x: number; y: number }
    timestamp: string
    sensor_type: string
    signal_strength: number | string
  }>
  path_history: Array<{ x: number; y: number }>
  last_error: string | null
  last_action_sent: {
    action: string
    success: boolean
    timestamp: number
  } | null
}

export default function RoverDashboard() {
  const [roverState, setRoverState] = useState<RoverState>({
    roverId: "NX-5432",
    status: "Initializing",
    batteryLevel: 87.5,
    isCharging: false,
    communicationStatus: "OK",
    position: { x: 45.76, y: 78.34 },
    ultrasonicDistance: 152.8,
    survivorSensors: {
      rfidDetected: false,
      irSignal: 12.3,
    },
    accelerometer: {
      x: 0.02,
      y: 0.01,
      z: 0.98,
      isTilted: false,
    },
  })

  const [survivorLog, setSurvivorLog] = useState<SurvivorLog[]>([])
  const [logEntries, setLogEntries] = useState<LogEntry[]>([
    { id: 1, message: "System initialized", timestamp: "14:30:05", type: "info" },
  ])

  // Path history for visualization
  const [pathHistory, setPathHistory] = useState<{ x: number; y: number }[]>([])

  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Add a new state variable for tracking if survivors are found
  const [survivorsFound, setSurvivorsFound] = useState(false)

  // Add a state for dark mode
  const [isDarkMode, setIsDarkMode] = useState(false)

  // Add a state to track if we're using simulation mode
  const [isSimulationMode, setIsSimulationMode] = useState(true)

  // API URL - use the Next.js API route we created
  const API_URL = "/api/state"

  // Add a useEffect to initialize the simulation mode immediately
  useEffect(() => {
    // Initialize with simulation data immediately
    simulateRoverState()

    // Then try to connect to the API
    fetchRoverState()

    // Add log entry for simulation mode
    setLogEntries((prev) => [
      ...prev,
      {
        id: prev.length + 1,
        message: "Starting in simulation mode",
        timestamp: new Date().toLocaleTimeString(),
        type: "info",
      },
    ])
  }, [])

  // Fetch rover state from API
  const fetchRoverState = async () => {
    try {
      // Attempt to fetch data from the API with a timeout
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

      const response = await fetch(API_URL, {
        signal: controller.signal,
        headers: {
          Accept: "application/json",
        },
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }

      // Try to parse the response as JSON
      let backendData
      const contentType = response.headers.get("content-type")
      if (contentType && contentType.includes("application/json")) {
        backendData = await response.json()

        // If we successfully got JSON data, update the state
        updateStateFromBackend(backendData)

        // If we were in simulation mode before, log that we're now connected to the API
        if (isSimulationMode) {
          setIsSimulationMode(false)
          setLogEntries((prev) => [
            ...prev,
            {
              id: prev.length + 1,
              message: "Connected to rover API",
              timestamp: new Date().toLocaleTimeString(),
              type: "success",
            },
          ])
        }
      } else {
        // Not JSON, fall back to simulation
        throw new Error("Response is not JSON")
      }
    } catch (error) {
      console.error("Failed to fetch rover state:", error)

      // Always fall back to simulation mode when there's an error
      if (!isSimulationMode) {
        setIsSimulationMode(true)
        setLogEntries((prev) => [
          ...prev,
          {
            id: prev.length + 1,
            message: "API connection failed, using simulation mode",
            timestamp: new Date().toLocaleTimeString(),
            type: "warning",
          },
        ])
      }

      simulateRoverState()
    }
  }

  // Update state from backend data
  const updateStateFromBackend = (backendData: BackendState) => {
    // Update rover state
    setRoverState((prevState) => ({
      ...prevState,
      roverId: backendData.session_id || "NX-5432",
      status: backendData.rover_status || "Unknown",
      batteryLevel: backendData.battery_level !== null ? backendData.battery_level : prevState.batteryLevel,
      isCharging: backendData.is_charging,
      communicationStatus: backendData.comms_ok ? "OK" : "Lost",
      position: backendData.position || prevState.position,
      ultrasonicDistance: backendData.sensors?.ultrasonic_distance || prevState.ultrasonicDistance,
      survivorSensors: {
        rfidDetected: backendData.sensors?.rfid_detected || false,
        irSignal: backendData.sensors?.ir_signal_strength || 0,
      },
      accelerometer: {
        x: backendData.sensors?.accelerometer?.x || 0,
        y: backendData.sensors?.accelerometer?.y || 0,
        z: backendData.sensors?.accelerometer?.z || 0,
        isTilted: false, // Calculate this based on accelerometer values if needed
      },
    }))

    // Update path history
    if (backendData.path_history && backendData.path_history.length > 0) {
      setPathHistory(backendData.path_history)
    }

    // Update survivor log
    if (backendData.survivors_found && backendData.survivors_found.length > 0) {
      const newSurvivorLog = backendData.survivors_found.map((survivor) => ({
        id: survivor.id,
        x: survivor.position.x,
        y: survivor.position.y,
        timestamp: survivor.timestamp,
        sensorType: survivor.sensor_type as "RFID" | "IR",
        signalStrength: typeof survivor.signal_strength === "number" ? survivor.signal_strength : undefined,
      }))

      setSurvivorLog(newSurvivorLog)

      // Set survivorsFound to true if there are any survivors
      setSurvivorsFound(newSurvivorLog.length > 0)
    }

    // Add log entries for important events
    if (backendData.last_action_sent) {
      const { action, success, timestamp } = backendData.last_action_sent
      const time = new Date(timestamp * 1000).toLocaleTimeString()

      setLogEntries((prev) => [
        ...prev,
        {
          id: prev.length + 1,
          message: `Action ${action} ${success ? "succeeded" : "failed"}`,
          timestamp: time,
          type: success ? "success" : "error",
        },
      ])
    }
  }

  // Simulate rover state for testing when backend is not available
  const simulateRoverState = () => {
    setRoverState((prevState) => {
      // Calculate new battery level based on charging state
      const newBatteryLevel = prevState.isCharging
        ? Math.min(100, prevState.batteryLevel + 0.5) // Charge faster
        : Math.max(0, prevState.batteryLevel - 0.1)

      // Determine if charging should start or stop
      let newIsCharging = prevState.isCharging
      let newStatus = prevState.status
      let newCommunicationStatus = prevState.communicationStatus

      // Start charging if battery is below 5%
      if (newBatteryLevel <= 5 && !newIsCharging) {
        newIsCharging = true
        newStatus = "Charging"

        // Add log entry
        setLogEntries((prev) => [
          ...prev,
          {
            id: prev.length + 1,
            message: "Battery critical. Initiating charging mode.",
            timestamp: new Date().toLocaleTimeString(),
            type: "warning",
          },
        ])
      }

      // Stop charging if battery reaches 80%
      if (newBatteryLevel >= 80 && newIsCharging) {
        newIsCharging = false
        newStatus = "Exploring"

        // Add log entry
        setLogEntries((prev) => [
          ...prev,
          {
            id: prev.length + 1,
            message: "Battery charged to 80%. Resuming normal operation.",
            timestamp: new Date().toLocaleTimeString(),
            type: "success",
          },
        ])
      }

      // Handle communication loss when battery is below 10%
      if (newBatteryLevel < 10) {
        newCommunicationStatus = "Lost"
        if (newStatus !== "Charging") {
          newStatus = "Comms Lost"
        }

        // Add log entry if this just happened
        if (prevState.communicationStatus === "OK") {
          setLogEntries((prev) => [
            ...prev,
            {
              id: prev.length + 1,
              message: "Battery below 10%. Communication signal lost.",
              timestamp: new Date().toLocaleTimeString(),
              type: "error",
            },
          ])
        }
      } else if (newCommunicationStatus === "Lost") {
        // Restore communication when battery is above 10%
        newCommunicationStatus = "OK"
        if (newStatus === "Comms Lost") {
          newStatus = newIsCharging ? "Charging" : "Exploring"
        }

        // Add log entry
        setLogEntries((prev) => [
          ...prev,
          {
            id: prev.length + 1,
            message: "Battery above 10%. Communication re-established.",
            timestamp: new Date().toLocaleTimeString(),
            type: "success",
          },
        ])
      }

      // Only update position if not charging and communication is OK
      const newPosition =
        !newIsCharging && newCommunicationStatus === "OK" && isRunning
          ? {
              x: prevState.position.x + (Math.random() * 0.1 - 0.05),
              y: prevState.position.y + (Math.random() * 0.1 - 0.05),
            }
          : prevState.position

      // Update path history if position changed
      if (newPosition.x !== prevState.position.x || newPosition.y !== prevState.position.y) {
        setPathHistory((prev) => [...prev, newPosition])
      }

      // Occasionally simulate a survivor detection
      if (Math.random() < 0.05 && isRunning && !newIsCharging && newCommunicationStatus === "OK") {
        const newSurvivor: SurvivorLog = {
          id: survivorLog.length + 1,
          x: newPosition.x,
          y: newPosition.y,
          timestamp: new Date().toISOString(),
          sensorType: Math.random() > 0.5 ? "RFID" : "IR",
          signalStrength: Math.random() > 0.5 ? Math.round(Math.random() * 100) : undefined,
        }

        setSurvivorLog((prev) => [...prev, newSurvivor])
        setSurvivorsFound(true)

        // Add log entry
        setLogEntries((prev) => [
          ...prev,
          {
            id: prev.length + 1,
            message: `${newSurvivor.sensorType} signal detected`,
            timestamp: new Date().toLocaleTimeString(),
            type: "success",
          },
        ])
      }

      return {
        ...prevState,
        batteryLevel: newBatteryLevel,
        isCharging: newIsCharging,
        status: isRunning ? newStatus : "Stopped",
        communicationStatus: newCommunicationStatus,
        position: newPosition,
        ultrasonicDistance: Math.max(50, prevState.ultrasonicDistance + (Math.random() * 10 - 5)),
        survivorSensors: {
          ...prevState.survivorSensors,
          irSignal: Math.max(0, prevState.survivorSensors.irSignal + (Math.random() * 5 - 2.5)),
        },
      }
    })
  }

  // Start/Stop rover
  const [isRunning, setIsRunning] = useState(true)

  const handleStartRover = async () => {
    try {
      // In a real implementation, send a start command to the backend
      // await fetch(`${API_URL}/start`, { method: 'POST' });

      setIsRunning(true)
      setRoverState((prev) => ({
        ...prev,
        status: prev.isCharging ? "Charging" : prev.communicationStatus === "Lost" ? "Comms Lost" : "Exploring",
      }))

      setLogEntries((prev) => [
        ...prev,
        {
          id: prev.length + 1,
          message: "Autonomous exploration started",
          timestamp: new Date().toLocaleTimeString(),
          type: "success",
        },
      ])
    } catch (error) {
      console.error("Failed to start rover:", error)
    }
  }

  const handleStopRover = async () => {
    try {
      // In a real implementation, send a stop command to the backend
      // await fetch(`${API_URL}/stop`, { method: 'POST' });

      setIsRunning(false)
      setRoverState((prev) => ({
        ...prev,
        status: "Stopped",
      }))

      setLogEntries((prev) => [
        ...prev,
        {
          id: prev.length + 1,
          message: "Rover stopped",
          timestamp: new Date().toLocaleTimeString(),
          type: "warning",
        },
      ])
    } catch (error) {
      console.error("Failed to stop rover:", error)
    }
  }

  // Add a function to handle deploying aid
  const handleDeployAid = async () => {
    try {
      // In a real implementation, send a deploy aid command to the backend
      // await fetch(`${API_URL}/deploy-aid`, { method: 'POST' });

      setLogEntries((prev) => [
        ...prev,
        {
          id: prev.length + 1,
          message: "Aid deployment initiated to survivor location",
          timestamp: new Date().toLocaleTimeString(),
          type: "success",
        },
      ])

      // Reset the survivors found state after a delay
      setTimeout(() => {
        setSurvivorsFound(false)
      }, 5000)
    } catch (error) {
      console.error("Failed to deploy aid:", error)
    }
  }

  // Add a function to toggle dark mode
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
    document.documentElement.classList.toggle("dark")
  }

  // Draw the map
  const drawMap = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set background color for dark mode
    if (isDarkMode) {
      ctx.fillStyle = "#1f2937" // dark gray background
      ctx.fillRect(0, 0, canvas.width, canvas.height)
    }

    // If there's no path history, don't try to draw anything
    if (pathHistory.length === 0) return

    // Set up coordinate transformation
    const padding = 30
    const minX = Math.min(...pathHistory.map((p) => p.x), ...survivorLog.map((s) => s.x))
    const maxX = Math.max(...pathHistory.map((p) => p.x), ...survivorLog.map((s) => s.x))
    const minY = Math.min(...pathHistory.map((p) => p.y), ...survivorLog.map((s) => s.y))
    const maxY = Math.max(...pathHistory.map((p) => p.y), ...survivorLog.map((s) => s.y))

    const rangeX = maxX - minX || 10
    const rangeY = maxY - minY || 10

    const scaleX = (canvas.width - padding * 2) / rangeX
    const scaleY = (canvas.height - padding * 2) / rangeY

    const transformX = (x: number) => (x - minX) * scaleX + padding
    const transformY = (y: number) => canvas.height - ((y - minY) * scaleY + padding)

    // Draw grid
    ctx.strokeStyle = isDarkMode ? "#374151" : "#e5e7eb" // darker grid lines for dark mode
    ctx.lineWidth = 0.5

    // Vertical grid lines
    for (let x = Math.floor(minX); x <= Math.ceil(maxX); x += 1) {
      ctx.beginPath()
      ctx.moveTo(transformX(x), padding)
      ctx.lineTo(transformX(x), canvas.height - padding)
      ctx.stroke()
    }

    // Horizontal grid lines
    for (let y = Math.floor(minY); y <= Math.ceil(maxY); y += 1) {
      ctx.beginPath()
      ctx.moveTo(padding, transformY(y))
      ctx.lineTo(canvas.width - padding, transformY(y))
      ctx.stroke()
    }

    // Draw path with glow effect
    if (isDarkMode) {
      // Add glow effect in dark mode
      ctx.shadowColor = "#3b82f6"
      ctx.shadowBlur = 5
    }

    ctx.strokeStyle = "#3b82f6"
    ctx.lineWidth = 2
    ctx.beginPath()
    pathHistory.forEach((point, index) => {
      if (index === 0) {
        ctx.moveTo(transformX(point.x), transformY(point.y))
      } else {
        ctx.lineTo(transformX(point.x), transformY(point.y))
      }
    })
    ctx.stroke()

    // Reset shadow
    ctx.shadowColor = "transparent"
    ctx.shadowBlur = 0

    // Draw survivor locations
    survivorLog.forEach((survivor) => {
      // Add glow effect for survivors in dark mode
      if (isDarkMode) {
        ctx.shadowColor = survivor.sensorType === "RFID" ? "#10b981" : "#f59e0b"
        ctx.shadowBlur = 8
      }

      ctx.fillStyle = survivor.sensorType === "RFID" ? "#10b981" : "#f59e0b"
      ctx.beginPath()
      ctx.arc(transformX(survivor.x), transformY(survivor.y), 6, 0, Math.PI * 2)
      ctx.fill()

      // Add a pulsing effect for survivors
      ctx.strokeStyle = survivor.sensorType === "RFID" ? "#10b981" : "#f59e0b"
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.arc(transformX(survivor.x), transformY(survivor.y), 10, 0, Math.PI * 2)
      ctx.stroke()

      // Reset shadow
      ctx.shadowColor = "transparent"
      ctx.shadowBlur = 0
    })

    // Draw current position with glow effect
    if (isDarkMode) {
      ctx.shadowColor = "#ef4444"
      ctx.shadowBlur = 10
    }

    ctx.fillStyle = "#ef4444"
    ctx.beginPath()
    ctx.arc(transformX(roverState.position.x), transformY(roverState.position.y), 8, 0, Math.PI * 2)
    ctx.fill()

    // Reset shadow
    ctx.shadowColor = "transparent"
    ctx.shadowBlur = 0

    // Draw direction indicator (simple arrow)
    const lastTwoPoints = pathHistory.slice(-2)
    if (lastTwoPoints.length === 2) {
      const [prevPoint, currentPoint] = lastTwoPoints
      const angle = Math.atan2(
        transformY(prevPoint.y) - transformY(currentPoint.y),
        transformX(prevPoint.x) - transformX(currentPoint.x),
      )

      ctx.save()
      ctx.translate(transformX(currentPoint.x), transformY(currentPoint.y))
      ctx.rotate(angle)

      ctx.strokeStyle = "#ef4444"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(0, 0)
      ctx.lineTo(-15, 0)
      ctx.stroke()

      ctx.beginPath()
      ctx.moveTo(-15, 0)
      ctx.lineTo(-10, -5)
      ctx.lineTo(-10, 5)
      ctx.closePath()
      ctx.fill()

      ctx.restore()
    }
  }

  // Poll for rover state and update map
  useEffect(() => {
    const interval = setInterval(() => {
      if (isSimulationMode) {
        simulateRoverState()
      } else {
        fetchRoverState()
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [isSimulationMode, isRunning])

  // Draw map whenever relevant data changes
  useEffect(() => {
    drawMap()
  }, [pathHistory, survivorLog, roverState.position, isDarkMode])

  // Get status color based on rover state
  const getStatusColor = (status: string) => {
    if (isDarkMode) {
      switch (status) {
        case "Exploring":
          return "text-green-400"
        case "Charging":
          return "text-blue-400"
        case "Avoiding Obstacle":
          return "text-yellow-400"
        case "Survivor Detected":
          return "text-purple-400"
        case "Comms Lost":
          return "text-red-400"
        case "Stopped":
          return "text-gray-400"
        case "Initializing":
          return "text-blue-400"
        default:
          return "text-gray-300"
      }
    } else {
      switch (status) {
        case "Exploring":
          return "text-green-600"
        case "Charging":
          return "text-blue-600"
        case "Avoiding Obstacle":
          return "text-yellow-600"
        case "Survivor Detected":
          return "text-purple-600"
        case "Comms Lost":
          return "text-red-600"
        case "Stopped":
          return "text-gray-600"
        case "Initializing":
          return "text-blue-600"
        default:
          return "text-gray-800"
      }
    }
  }

  // Get icon for log entry type
  const getLogIcon = (type: string) => {
    switch (type) {
      case "info":
        return <Activity className="h-4 w-4 text-blue-600" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "error":
        return <X className="h-4 w-4 text-red-600" />
      case "success":
        return <Check className="h-4 w-4 text-green-600" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  return (
    <div
      className={`min-h-screen ${isDarkMode ? "dark bg-gradient-to-br from-gray-900 to-gray-800 text-gray-100" : "bg-gradient-to-br from-blue-50 to-white text-gray-800"}`}
    >
      {/* Header */}
      <header
        className={`border-b ${isDarkMode ? "border-gray-700 bg-gray-800/80" : "border-gray-200 bg-white/80"} backdrop-blur-sm shadow-sm`}
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`${isDarkMode ? "bg-primary/20" : "bg-primary/10"} p-2 rounded-md`}>
                <Activity className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className={`text-xl font-bold ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                  Nova Explorer System
                </h1>
                <p className={`text-sm ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                  Rover ID: {roverState.roverId} {isSimulationMode && "(Simulation)"}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Badge
                variant={roverState.communicationStatus === "OK" ? "outline" : "destructive"}
                className={
                  roverState.communicationStatus === "OK"
                    ? `${isDarkMode ? "bg-green-900/30 text-green-400 border-green-700" : "bg-green-100 text-green-700 border-green-200"} hover:bg-green-100`
                    : ""
                }
              >
                <Wifi className="h-3 w-3 mr-1" />
                {roverState.communicationStatus}
              </Badge>
              <Badge
                variant="outline"
                className={`${
                  isRunning
                    ? isDarkMode
                      ? "bg-green-900/30 text-green-400 border-green-700"
                      : "bg-green-100 text-green-700 border-green-200"
                    : isDarkMode
                      ? "bg-yellow-900/30 text-yellow-400 border-yellow-700"
                      : "bg-yellow-100 text-yellow-700 border-yellow-200"
                } hover:bg-transparent`}
              >
                {isRunning ? "Active" : "Standby"}
              </Badge>
              <button
                onClick={toggleDarkMode}
                className={`p-2 rounded-full ${isDarkMode ? "bg-gray-700 text-yellow-300 hover:bg-gray-600" : "bg-gray-100 text-gray-700 hover:bg-gray-200"} transition-colors`}
              >
                {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Status Cards */}
          <div className="space-y-6">
            {/* Rover Status Card */}
            <Card
              className={`${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} shadow-sm transition-colors`}
            >
              <CardHeader className="pb-2">
                <CardTitle className={`text-lg font-medium ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                  Rover Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {/* Status */}
                  <div
                    className={`${isDarkMode ? "bg-gray-700/50" : "bg-gray-50"} rounded-lg p-4 flex flex-col transition-colors`}
                  >
                    <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>Status</span>
                    <div className="flex items-center mt-1">
                      <div
                        className={`h-2 w-2 rounded-full mr-2 ${
                          roverState.status === "Stopped"
                            ? "bg-red-500"
                            : roverState.status === "Initializing"
                              ? "bg-blue-500"
                              : "bg-green-500"
                        }`}
                      ></div>
                      <span className={`text-lg font-semibold ${getStatusColor(roverState.status)}`}>
                        {roverState.status}
                      </span>
                    </div>
                  </div>

                  {/* Battery */}
                  <div
                    className={`${isDarkMode ? "bg-gray-700/50" : "bg-gray-50"} rounded-lg p-4 flex flex-col transition-colors`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>Battery</span>
                      {roverState.isCharging && (
                        <Badge
                          variant="outline"
                          className={`${isDarkMode ? "bg-blue-900/30 text-blue-400 border-blue-700" : "bg-blue-100 text-blue-700 border-blue-200"} text-xs`}
                        >
                          <Zap className="h-3 w-3 mr-1" />
                          Charging
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center mt-1">
                      <div className="relative">
                        <Battery
                          className={`h-5 w-5 mr-2 ${
                            roverState.batteryLevel > 50
                              ? "text-green-600"
                              : roverState.batteryLevel > 20
                                ? "text-yellow-600"
                                : "text-red-600"
                          }`}
                        />
                        {roverState.isCharging && (
                          <Zap
                            className={`h-3 w-3 absolute -top-1 -right-1 ${isDarkMode ? "text-blue-400" : "text-blue-600"} animate-pulse`}
                          />
                        )}
                      </div>
                      <span className="text-lg font-semibold">{roverState.batteryLevel.toFixed(1)}%</span>
                      {roverState.isCharging && (
                        <span
                          className={`ml-2 text-xs ${isDarkMode ? "text-blue-400" : "text-blue-600"} animate-pulse`}
                        >
                          Charging
                        </span>
                      )}
                    </div>
                    <Progress
                      value={roverState.batteryLevel}
                      className={`h-1.5 mt-2 ${isDarkMode ? "bg-gray-600" : "bg-gray-200"}`}
                      indicatorClassName={
                        roverState.batteryLevel > 50
                          ? "bg-green-500"
                          : roverState.batteryLevel > 20
                            ? "bg-yellow-500"
                            : "bg-red-500"
                      }
                    />
                  </div>

                  {/* Position */}
                  <div
                    className={`${isDarkMode ? "bg-gray-700/50" : "bg-gray-50"} rounded-lg p-4 flex flex-col transition-colors`}
                  >
                    <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>Position</span>
                    <div className="flex items-center mt-1">
                      <MapPin className="h-5 w-5 mr-2 text-primary" />
                      <span className="text-sm font-medium">
                        X: {roverState.position.x.toFixed(2)}, Y: {roverState.position.y.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* Ultrasonic */}
                  <div
                    className={`${isDarkMode ? "bg-gray-700/50" : "bg-gray-50"} rounded-lg p-4 flex flex-col transition-colors`}
                  >
                    <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>Ultrasonic</span>
                    <div className="flex items-center mt-1">
                      <Ruler className="h-5 w-5 mr-2 text-primary" />
                      <span className="text-sm font-medium">{roverState.ultrasonicDistance.toFixed(1)} cm</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sensor Data Card */}
            <Card
              className={`${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} shadow-sm transition-colors`}
            >
              <CardHeader className="pb-2">
                <CardTitle className={`text-lg font-medium ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                  Sensor Data
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Survivor Sensors */}
                  <div className={`${isDarkMode ? "bg-gray-700/50" : "bg-gray-50"} rounded-lg p-4 transition-colors`}>
                    <h3 className={`text-sm font-medium mb-3 ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                      Survivor Detection
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex flex-col">
                        <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>RFID Status</span>
                        <div className="flex items-center mt-1">
                          <Radio
                            className={`h-4 w-4 mr-2 ${roverState.survivorSensors.rfidDetected ? "text-green-600" : isDarkMode ? "text-gray-600" : "text-gray-400"}`}
                          />
                          <span
                            className={`text-sm font-medium ${roverState.survivorSensors.rfidDetected ? "text-green-600" : isDarkMode ? "text-gray-400" : "text-gray-500"}`}
                          >
                            {roverState.survivorSensors.rfidDetected ? "Detected" : "Not Detected"}
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>IR Signal</span>
                        <div className="flex items-center mt-1">
                          <Radio
                            className={`h-4 w-4 mr-2 ${roverState.survivorSensors.irSignal > 50 ? "text-yellow-600" : isDarkMode ? "text-gray-600" : "text-gray-400"}`}
                          />
                          <span className="text-sm font-medium">{roverState.survivorSensors.irSignal.toFixed(1)}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Accelerometer */}
                  <div className={`${isDarkMode ? "bg-gray-700/50" : "bg-gray-50"} rounded-lg p-4 transition-colors`}>
                    <h3 className={`text-sm font-medium mb-3 ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                      Accelerometer
                    </h3>
                    <div className="grid grid-cols-4 gap-2">
                      <div className="flex flex-col">
                        <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>X</span>
                        <span className="text-sm font-medium">{roverState.accelerometer.x.toFixed(2)}</span>
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>Y</span>
                        <span className="text-sm font-medium">{roverState.accelerometer.y.toFixed(2)}</span>
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>Z</span>
                        <span className="text-sm font-medium">{roverState.accelerometer.z.toFixed(2)}</span>
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>Tilted</span>
                        <span
                          className={`text-sm font-medium ${roverState.accelerometer.isTilted ? "text-yellow-600" : "text-green-600"}`}
                        >
                          {roverState.accelerometer.isTilted ? "Yes" : "No"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Controls */}
            <Card
              className={`${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} shadow-sm transition-colors`}
            >
              <CardHeader className="pb-2">
                <CardTitle className={`text-lg font-medium ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                  Controls
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col space-y-4">
                  <div className="flex space-x-4">
                    <Button
                      onClick={handleStartRover}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                      disabled={isRunning || roverState.communicationStatus === "Lost"}
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Start
                    </Button>
                    <Button
                      onClick={handleStopRover}
                      className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                      disabled={!isRunning || roverState.communicationStatus === "Lost"}
                    >
                      <Square className="h-4 w-4 mr-2" />
                      Stop
                    </Button>
                  </div>

                  {/* Deploy Aid Button */}
                  <Button
                    onClick={handleDeployAid}
                    className={`w-full ${survivorsFound ? "bg-purple-600 hover:bg-purple-700" : "bg-gray-400"} text-white transition-all transform hover:scale-105 ${survivorsFound ? "animate-pulse" : ""}`}
                    disabled={!survivorsFound || roverState.communicationStatus === "Lost"}
                  >
                    <Truck className="h-4 w-4 mr-2" />
                    Deploy Aid
                  </Button>
                  {survivorsFound && (
                    <p className="text-xs text-center text-purple-500 animate-pulse font-medium">
                      Survivors detected! Aid deployment available.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Middle Column - Map Visualization */}
          <div className="lg:col-span-2">
            <Card
              className={`${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} shadow-sm h-full transition-colors`}
            >
              <CardHeader className="pb-2">
                <CardTitle className={`text-lg font-medium ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                  Path Visualization
                </CardTitle>
                <CardDescription className={`${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                  Current position and historical path with survivor locations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className={`${isDarkMode ? "bg-gray-700/50" : "bg-gray-50"} rounded-lg p-2 h-[500px] transition-colors`}
                >
                  <canvas ref={canvasRef} width={800} height={500} className="w-full h-full"></canvas>
                </div>
                <div className="flex items-center justify-center mt-4 space-x-6">
                  <div className="flex items-center">
                    <div className="h-3 w-3 rounded-full bg-red-500 mr-2"></div>
                    <span className={`text-xs ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                      Current Position
                    </span>
                  </div>
                  <div className="flex items-center">
                    <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
                    <span className={`text-xs ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>RFID Detection</span>
                  </div>
                  <div className="flex items-center">
                    <div className="h-3 w-3 rounded-full bg-yellow-500 mr-2"></div>
                    <span className={`text-xs ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>IR Detection</span>
                  </div>
                  <div className="flex items-center">
                    <div className="h-1 w-6 bg-blue-500 mr-2"></div>
                    <span className={`text-xs ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>Path History</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Bottom Row - Tabs for Survivor Log and System Log */}
        <div className="mt-6">
          <Tabs defaultValue="survivor-log" className="w-full">
            <TabsList className={`${isDarkMode ? "bg-gray-700 border-gray-600" : "bg-gray-100 border-gray-200"}`}>
              <TabsTrigger
                value="survivor-log"
                className="data-[state=active]:bg-primary data-[state=active]:text-white"
              >
                <User className="h-4 w-4 mr-2" />
                Survivor Log
              </TabsTrigger>
              <TabsTrigger value="system-log" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                <Activity className="h-4 w-4 mr-2" />
                System Log
              </TabsTrigger>
            </TabsList>
            <TabsContent value="survivor-log" className="mt-4">
              <Card
                className={`${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} shadow-sm transition-colors`}
              >
                <CardHeader className="pb-2">
                  <CardTitle className={`text-lg font-medium ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                    Survivor Detection Log
                  </CardTitle>
                  <CardDescription className={`${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                    Record of all survivor signals detected during the mission
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow className={`${isDarkMode ? "border-gray-700" : "border-gray-200"}`}>
                        <TableHead className={`${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>ID</TableHead>
                        <TableHead className={`${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>Location</TableHead>
                        <TableHead className={`${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>Timestamp</TableHead>
                        <TableHead className={`${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                          Sensor Type
                        </TableHead>
                        <TableHead className={`${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                          Signal Strength
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {survivorLog.length > 0 ? (
                        survivorLog.map((log) => (
                          <TableRow key={log.id} className={`${isDarkMode ? "border-gray-700" : "border-gray-200"}`}>
                            <TableCell className="font-medium">{log.id}</TableCell>
                            <TableCell>
                              X: {log.x.toFixed(2)}, Y: {log.y.toFixed(2)}
                            </TableCell>
                            <TableCell>{new Date(log.timestamp).toLocaleTimeString()}</TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className={
                                  log.sensorType === "RFID"
                                    ? isDarkMode
                                      ? "bg-green-900/30 text-green-400 border-green-700"
                                      : "bg-green-100 text-green-700 border-green-200"
                                    : isDarkMode
                                      ? "bg-yellow-900/30 text-yellow-400 border-yellow-700"
                                      : "bg-yellow-100 text-yellow-700 border-yellow-200"
                                }
                              >
                                {log.sensorType}
                              </Badge>
                            </TableCell>
                            <TableCell>{log.signalStrength ? `${log.signalStrength}%` : "N/A"}</TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-4">
                            <span className={`${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                              No survivors detected yet
                            </span>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="system-log" className="mt-4">
              <Card
                className={`${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} shadow-sm transition-colors`}
              >
                <CardHeader className="pb-2">
                  <CardTitle className={`text-lg font-medium ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                    System Log
                  </CardTitle>
                  <CardDescription className={`${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                    Recent system events and status messages
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[300px] pr-4">
                    <div className="space-y-2">
                      {logEntries.map((log) => (
                        <div
                          key={log.id}
                          className={`flex items-start space-x-3 p-2 rounded-md ${isDarkMode ? "bg-gray-700/50" : "bg-gray-50"} transition-colors`}
                        >
                          <div className="mt-0.5">{getLogIcon(log.type)}</div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <p className={`text-sm font-medium ${isDarkMode ? "text-gray-200" : "text-gray-800"}`}>
                                {log.message}
                              </p>
                              <span className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                                {log.timestamp}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

